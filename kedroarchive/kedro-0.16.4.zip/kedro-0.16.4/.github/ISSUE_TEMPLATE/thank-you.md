---
name: Say thank you
about: Tell us how you use Kedro and help us grow a community
title: '<Title>'
labels: 'Issue: Thank You'
assignees: ''

---

## Let us know
If you (or your company) are using Kedro - please let us know. We'd love to hear from you!

## Making Kedro even better
If you would like to help Kedro - any of the following is greatly appreciated.

- [ ] Give the repository a star
- [ ] Help out with issues
- [ ] Review pull requests
- [ ] Blog about Kedro
- [ ] Make tutorials
- [ ] Give talks
