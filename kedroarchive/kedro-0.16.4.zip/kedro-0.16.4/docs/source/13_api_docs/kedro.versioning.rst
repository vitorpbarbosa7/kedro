kedro.versioning
================

.. rubric:: Description

.. automodule:: kedro.versioning

Base Classes
------------

.. autosummary::
    :toctree:
    :template: autosummary/class.rst

    kedro.versioning.Journal

Modules
-------

.. autosummary::
    :toctree:
    :template: autosummary/base.rst


Errors
------

.. autosummary::
    :toctree:
    :template: autosummary/class.rst
