kedro.extras.logging
====================

.. rubric:: Description

.. automodule:: kedro.extras.logging

   .. rubric:: A color log handler

   .. autosummary::
      :toctree:
      :template: autosummary/base.rst

      kedro.extras.logging.ColorHandler
