kedro.pipeline
==============

.. rubric:: Description

.. automodule:: kedro.pipeline

   .. rubric:: Classes

   .. autosummary::
       :toctree:
       :template: autosummary/class.rst

       kedro.pipeline.Pipeline
       kedro.pipeline.node.Node

   .. rubric:: Functions

   .. autosummary::
       :toctree:
       :template: autosummary/base.rst

       kedro.pipeline.node

   .. rubric:: Decorators

   .. autosummary::
       :toctree:
       :template: autosummary/base.rst

       kedro.pipeline.decorators.log_time
