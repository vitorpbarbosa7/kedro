kedro.config
============

.. rubric:: Description

.. automodule:: kedro.config

   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: autosummary/class.rst

      kedro.config.ConfigLoader
      kedro.config.TemplatedConfigLoader
