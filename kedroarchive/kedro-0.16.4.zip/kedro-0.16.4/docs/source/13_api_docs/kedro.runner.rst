kedro.runner
=================

.. rubric:: Description

.. automodule:: kedro.runner

   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: autosummary/class.rst

      kedro.runner.AbstractRunner
      kedro.runner.SequentialRunner
      kedro.runner.ParallelRunner
      kedro.runner.ThreadRunner
