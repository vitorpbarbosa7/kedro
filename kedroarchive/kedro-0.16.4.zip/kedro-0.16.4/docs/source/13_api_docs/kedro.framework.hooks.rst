kedro.framework.hooks
=====================

.. rubric:: Description

.. automodule:: kedro.framework.hooks

Data Catalog Hooks
-------------------

.. autosummary::
    :toctree:
    :template: autosummary/class.rst

    kedro.framework.hooks.specs.DataCatalogSpecs

Node Hooks
-------------------

.. autosummary::
    :toctree:
    :template: autosummary/class.rst

    kedro.framework.hooks.specs.NodeSpecs

Pipeline Hooks
-------------------

.. autosummary::
    :toctree:
    :template: autosummary/class.rst

    kedro.framework.hooks.specs.PipelineSpecs
