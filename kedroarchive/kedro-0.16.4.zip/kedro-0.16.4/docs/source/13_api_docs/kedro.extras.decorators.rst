kedro.extras.decorators
=======================

.. rubric:: Description

.. automodule:: kedro.extras.decorators

   .. rubric:: Node/Pipeline Decorators

   .. autosummary::
      :toctree:
      :template: autosummary/base.rst

      kedro.extras.decorators.retry_node.retry
      kedro.extras.decorators.memory_profiler.mem_profile
