kedro.framework.context
=======================

.. rubric:: Description

.. automodule:: kedro.framework.context

Base Classes
------------

.. autosummary::
    :toctree:
    :template: autosummary/class.rst

    kedro.framework.context.KedroContext

Functions
---------

.. autosummary::
    :toctree:
    :template: autosummary/base.rst

    kedro.framework.context.load_context


Errors
------

.. autosummary::
    :toctree:
    :template: autosummary/class.rst

    kedro.framework.context.KedroContextError
