kedro.framework.cli
===================

.. rubric:: Description

.. automodule:: kedro.framework.cli

   .. rubric:: Functions

   .. autosummary::
       :toctree:
       :template: autosummary/base.rst

       kedro.framework.cli.get_project_context
