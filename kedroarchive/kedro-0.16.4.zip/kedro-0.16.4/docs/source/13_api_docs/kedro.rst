kedro
=====

.. rubric:: Description

.. automodule:: kedro

.. rubric:: Modules

.. autosummary::
  :toctree:
  :template: autosummary/module.rst

  kedro.config
  kedro.framework.hooks
  kedro.io
  kedro.pipeline
  kedro.runner
  kedro.framework.context
  kedro.framework.cli
  kedro.versioning
  kedro.extras.datasets
  kedro.extras.decorators
  kedro.extras.transformers
  kedro.extras.logging
