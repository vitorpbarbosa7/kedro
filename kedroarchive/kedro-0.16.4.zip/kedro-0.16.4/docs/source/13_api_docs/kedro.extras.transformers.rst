kedro.extras.transformers
=========================

.. rubric:: Description

.. automodule:: kedro.extras.transformers

   .. rubric:: Transformers

   .. autosummary::
      :toctree:
      :template: autosummary/base.rst

      kedro.extras.transformers.memory_profiler.ProfileMemoryTransformer
      kedro.extras.transformers.time_profiler.ProfileTimeTransformer
