# Images and icons

## White background

### Icon
![Icon on white background](../meta/images/kedro_icon_no-type_whitebg.svg)

### Icon with text
![Icon with text on white background](../meta/images/kedro_icon_type_whitebg.svg)

## Black background

### Icon
![Icon on black background](../meta/images/kedro_icon_no-type_blackbg.svg)


### Icon with text
![Icon with text on black background](../meta/images/kedro_icon_type_blackbg.svg)
