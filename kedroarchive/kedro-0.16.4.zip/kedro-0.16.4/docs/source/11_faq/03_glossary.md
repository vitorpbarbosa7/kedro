# Glossary

CLI (command line interface) tool

Configuration

Data catalog

Data pipelines

Dataset

Development workflow framework

Local environment

Machine learning model

Node

Pipeline

Pipeline abstraction

Production environment

Production ready

Project template

Python package

Runner

Software engineering best-practice

Virtual environments
